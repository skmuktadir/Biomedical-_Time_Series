# Delete the failed database
rm optimize_physio4000.db

# Run again - it should work now!
python optimize.py --task physio4000 --n_trials 10 --epoch 20 --patience 5