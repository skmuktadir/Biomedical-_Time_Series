import optuna
import subprocess
import argparse
import re
import os
import json
from datetime import datetime

def parse_output(output):
    """Parse metrics from main.py output"""
    metrics = {}
    
    # Look for Testing results - format: Testing, Epoch X, acc: X.XXX, auroc: X.XXX, auprc: X.XXX, f1: X.XXX, br: X.XXX
    # Pattern matches the log_info output format
    test_pattern = r'Testing.*?auroc:\s*([\d.]+).*?auprc:\s*([\d.]+).*?f1:\s*([\d.]+).*?acc:\s*([\d.]+).*?br:\s*([\d.]+)'
    match = re.search(test_pattern, output, re.IGNORECASE | re.DOTALL)
    
    if match:
        metrics['auroc'] = float(match.group(1))
        metrics['auprc'] = float(match.group(2))
        metrics['f1'] = float(match.group(3))
        metrics['acc'] = float(match.group(4))
        metrics['br'] = float(match.group(5))
        return metrics
    
    # Alternative: look for last validation results if testing not found
    valid_pattern = r'Valid.*?auroc:\s*([\d.]+).*?auprc:\s*([\d.]+).*?f1:\s*([\d.]+)'
    match = re.search(valid_pattern, output, re.IGNORECASE | re.DOTALL)
    
    if match:
        metrics['auroc'] = float(match.group(1))
        metrics['auprc'] = float(match.group(2))
        metrics['f1'] = float(match.group(3))
        return metrics
    
    return None


def objective(trial, task, data_path, base_args):
    """Optuna objective function to optimize hyperparameters"""
    
    # Define hyperparameter search space - REDUCED FOR LOW MEMORY GPU
    d_model = trial.suggest_categorical('d_model', [32, 64])  # Reduced from [32, 64, 128]
    d_inner_hid = trial.suggest_categorical('d_inner_hid', [32, 64])  # Reduced from [32, 64, 128]
    
    # n_head should divide d_model evenly for multi-head attention
    n_head = trial.suggest_categorical('n_head', [1, 2])  # Reduced from [1, 2, 4]
    
    n_layers = trial.suggest_int('n_layers', 1, 3)  # Reduced from 1-4
    
    # d_k and d_v are typically d_model // n_head
    d_k = trial.suggest_categorical('d_k', [4, 8, 16])  # Reduced from [4, 8, 16, 32]
    d_v = trial.suggest_categorical('d_v', [4, 8, 16])  # Reduced from [4, 8, 16, 32]
    
    # Learning rate on log scale
    lr = trial.suggest_float('lr', 1e-4, 5e-3, log=True)
    
    # Optional: add dropout
    dropout = trial.suggest_float('dropout', 0.0, 0.3)
    
    # Optional: add weight_decay (log scale requires low > 0)
    weight_decay = trial.suggest_float('weight_decay', 1e-6, 1e-3, log=True)
    
    # Optional: batch size - REDUCED FOR LOW MEMORY
    batch_size = trial.suggest_categorical('batch_size', [16, 32])  # Reduced from [32, 64, 128]
    
    # Build command
    cmd = [
        'python', 'main.py',
        '--data_path', data_path,
        '--d_model', str(d_model),
        '--d_inner_hid', str(d_inner_hid),
        '--n_head', str(n_head),
        '--n_layers', str(n_layers),
        '--d_k', str(d_k),
        '--d_v', str(d_v),
        '--lr', f'{lr:.6f}',
        '--dropout', f'{dropout:.3f}',
        '--weight_decay', f'{weight_decay:.6f}',
        '--batch_size', str(batch_size),
        '--task', task,
        '--seed', str(trial.number),  # Use trial number as seed for reproducibility
    ]
    
    # Add any additional base arguments
    for key, value in base_args.items():
        cmd.extend([f'--{key}', str(value)])
    
    print(f"\n[Trial {trial.number}] Running: {' '.join(cmd)}")
    
    # Run the training
    try:
        result = subprocess.run(
            cmd, 
            capture_output=True, 
            text=True, 
            timeout=7200  # 2 hour timeout
        )
        
        output = result.stdout + result.stderr
        
        # Parse metrics
        metrics = parse_output(output)
        
        if metrics is None:
            print(f"[Trial {trial.number}] Could not parse metrics from output")
            print("Output snippet:", output[-1000:])  # Print last 1000 chars
            return float('-inf')  # Return worst value for maximization
        
        # Log all metrics for this trial
        for key, value in metrics.items():
            trial.set_user_attr(key, value)
        
        print(f"[Trial {trial.number}] Metrics: {metrics}")
        
        # Return AUROC as primary metric (maximize)
        return metrics.get('auroc', 0.0)
        
    except subprocess.TimeoutExpired:
        print(f"[Trial {trial.number}] Timed out")
        return float('-inf')
    except Exception as e:
        print(f"[Trial {trial.number}] Error: {e}")
        import traceback
        traceback.print_exc()
        return float('-inf')


def optimize_task(task, data_path, n_trials=50, study_name=None, base_args=None):
    """Run optimization for a specific task"""
    
    if base_args is None:
        base_args = {}
    
    if study_name is None:
        study_name = f"optimize_{task}"
    
    # Create or load study
    storage = f"sqlite:///{study_name}.db"
    
    study = optuna.create_study(
        study_name=study_name,
        storage=storage,
        load_if_exists=True,
        direction='maximize',  # Maximize AUROC
        pruner=optuna.pruners.MedianPruner(
            n_startup_trials=5,
            n_warmup_steps=10,
        )
    )
    
    print(f"\n{'='*80}")
    print(f"Starting optimization for task: {task}")
    print(f"Number of trials: {n_trials}")
    print(f"Study name: {study_name}")
    print(f"Database: {storage}")
    print(f"{'='*80}\n")
    
    # Run optimization
    study.optimize(
        lambda trial: objective(trial, task, data_path, base_args),
        n_trials=n_trials,
        show_progress_bar=False,  # We print our own progress
        callbacks=[lambda study, trial: print(f"\n{'='*80}\nCompleted trial {trial.number}: AUROC = {trial.value:.4f}\n{'='*80}\n")]
    )
    
    # Print results
    print(f"\n{'='*80}")
    print(f"Optimization completed for task: {task}")
    print(f"{'='*80}")
    print(f"Number of finished trials: {len(study.trials)}")
    print(f"Best trial: {study.best_trial.number}")
    print(f"Best AUROC: {study.best_value:.6f}")
    
    # Get all metrics for best trial
    best_trial = study.best_trial
    print(f"\nAll metrics for best trial:")
    for key, value in best_trial.user_attrs.items():
        print(f"  {key}: {value:.6f}")
    
    print(f"\nBest hyperparameters:")
    for key, value in study.best_params.items():
        print(f"  {key}: {value}")
    
    # Generate command with best parameters
    best_params = study.best_params
    cmd = f"python main.py --data_path {data_path} "
    cmd += f"--d_model {best_params['d_model']} "
    cmd += f"--d_inner_hid {best_params['d_inner_hid']} "
    cmd += f"--n_head {best_params['n_head']} "
    cmd += f"--n_layers {best_params['n_layers']} "
    cmd += f"--d_k {best_params['d_k']} "
    cmd += f"--d_v {best_params['d_v']} "
    cmd += f"--lr {best_params['lr']:.6f} "
    cmd += f"--dropout {best_params.get('dropout', 0.0):.3f} "
    cmd += f"--weight_decay {best_params.get('weight_decay', 0.0):.6f} "
    cmd += f"--batch_size {best_params.get('batch_size', 64)} "
    cmd += f"--task '{task}'"
    
    print(f"\nCommand to run with best parameters:")
    print(cmd)
    
    # Save best parameters to file
    result_file = f"{study_name}_best_params.json"
    with open(result_file, 'w') as f:
        json.dump({
            'task': task,
            'best_trial': best_trial.number,
            'best_auroc': study.best_value,
            'metrics': best_trial.user_attrs,
            'hyperparameters': best_params,
            'command': cmd,
            'timestamp': datetime.now().isoformat()
        }, f, indent=2)
    print(f"\nBest parameters saved to: {result_file}")
    print(f"{'='*80}\n")
    
    # Print top 5 trials
    print("Top 5 trials:")
    top_trials = sorted(study.trials, key=lambda t: t.value if t.value is not None else float('-inf'), reverse=True)[:5]
    for i, trial in enumerate(top_trials, 1):
        auroc = trial.user_attrs.get('auroc', trial.value)
        auprc = trial.user_attrs.get('auprc', 'N/A')
        print(f"  {i}. Trial {trial.number}: AUROC={auroc:.4f}, AUPRC={auprc}")
    
    return study


def run_with_best_params(study_name, task, data_path):
    """Run training with best parameters from optimization"""
    result_file = f"{study_name}_best_params.json"
    
    if not os.path.exists(result_file):
        print(f"Error: {result_file} not found. Run optimization first.")
        return
    
    with open(result_file, 'r') as f:
        results = json.load(f)
    
    print(f"Running with best parameters from {result_file}")
    print(f"Best AUROC from optimization: {results['best_auroc']:.6f}")
    print(f"\nCommand: {results['command']}")
    
    # Run the command
    os.system(results['command'])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Optimize hyperparameters with Optuna')
    parser.add_argument('--task', type=str, required=True, 
                        choices=['physio4000', 'physio8000', 'physio12000', 'mimic_iv'],
                        help='Task to optimize')
    parser.add_argument('--data_path', type=str, default='Data/',
                        help='Path to data')
    parser.add_argument('--n_trials', type=int, default=50,
                        help='Number of optimization trials')
    parser.add_argument('--study_name', type=str, default=None,
                        help='Name for the Optuna study (default: optimize_<task>)')
    parser.add_argument('--epoch', type=int, default=30,
                        help='Number of epochs for each trial (reduce for faster optimization)')
    parser.add_argument('--patience', type=int, default=5,
                        help='Early stopping patience')
    parser.add_argument('--run_best', action='store_true',
                        help='Run training with best parameters instead of optimizing')
    
    args = parser.parse_args()
    
    # Adjust data_path for mimic_iv
    if args.task == 'mimic_iv' and args.data_path == 'Data/':
        args.data_path = 'Data/mimic-iv-2.2/'
    
    study_name = args.study_name or f"optimize_{args.task}"
    
    if args.run_best:
        # Run with best parameters
        run_with_best_params(study_name, args.task, args.data_path)
    else:
        # Run optimization
        base_args = {
            'epoch': args.epoch,
            'patience': args.patience,
        }
        
        study = optimize_task(
            task=args.task,
            data_path=args.data_path,
            n_trials=args.n_trials,
            study_name=study_name,
            base_args=base_args
        )
        
        # Optionally, create visualizations
        try:
            import optuna.visualization as vis
            
            print("Generating visualizations...")
            
            # Optimization history
            fig = vis.plot_optimization_history(study)
            fig.write_html(f"{study_name}_optimization_history.html")
            
            # Parameter importances
            try:
                fig = vis.plot_param_importances(study)
                fig.write_html(f"{study_name}_param_importances.html")
            except:
                print("Could not generate parameter importance plot (need more trials)")
            
            # Parallel coordinate plot
            try:
                fig = vis.plot_parallel_coordinate(study)
                fig.write_html(f"{study_name}_parallel_coordinate.html")
            except:
                print("Could not generate parallel coordinate plot")
            
            # Contour plot for key parameters
            try:
                fig = vis.plot_contour(study, params=['lr', 'd_model'])
                fig.write_html(f"{study_name}_contour_lr_dmodel.html")
            except:
                print("Could not generate contour plot")
            
            print(f"\nVisualizations saved to {study_name}_*.html")
            
        except ImportError:
            print("\nInstall plotly for visualizations: pip install plotly kaleido")
        except Exception as e:
            print(f"Error generating visualizations: {e}")