# LFVDNet
1.Extract the Data/mimic-iv-2.2/decom.zip file to "Archive-Name" Folder.

2.Run the run.sh.
